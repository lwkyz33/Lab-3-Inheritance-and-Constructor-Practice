package lab3;

public class Main {
	public static void main(String [] args) {
		
		Person p = new Person("Lucas", 20);
		p.introduce();
		System.out.println();
		
		Student s = new Student("Saif", 25, "Rutgers");
		s.introduce();
		System.out.println();
		
		Employee e = new Employee("Mike", 30,  50000);
		e.introduce();
		e.displaySalary();
		System.out.println();
		
		Manager m = new Manager("Victor", 35, 100000, 5);
		m.introduce();
		m.displaySalary();
		System.out.println();
		
		Person []people = new Person[3];
		people[0] = new Person("Jack", 40);
		people[1] = new Student("Emily", 45, "Rutgers");
		people[2] = new Employee("Casey", 50, 50000);
		System.out.println("Polymorphism Demo.");
		for (Person person : people) {
			person.introduce();
			System.out.println();
			
			if (person instanceof Employee) {
				((Employee) person).displaySalary();
			}
			System.out.println();
		}
	}
}
