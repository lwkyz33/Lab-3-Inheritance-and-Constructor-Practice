package lab3;

public class Person {
	String name;
	int age;
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public void introduce() {
		System.out.println("Hi, my name is " + name + " and I am " + age + " years old.");
	}
}
class Student extends Person {
	String school;
	public Student(String name, int age, String school) {
		super(name, age);
		this.school = school;
	}
	@Override
	public void introduce() {
		super.introduce();
		System.out.println("I attend " + school + ".");
	}
}
class Employee extends Person {
	double salary;
	public Employee(String name, int age, double salary) {
		super(name, age);
		this.salary = salary;
	}
	public void displaySalary() {
		System.out.println("My salary is $" + salary + ".");
	}
}
class Manager extends Employee {
	int teamSize;
	public Manager(String name, int age, double salary, int teamSize) {
		super(name, age, salary);
		this.teamSize = teamSize;
	}
	@Override
	public void displaySalary() {
		super.displaySalary();
		System.out.println("I manage a team of " + teamSize + " people.");
	}
}